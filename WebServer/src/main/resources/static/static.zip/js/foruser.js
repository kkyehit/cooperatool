$("#modalY").click(function(){
    var sName = $("#s_name").val();
    var sID = $("#s_id").val();
    var sPW = $("#pwd1").val();
    alert("dasfadf");
});