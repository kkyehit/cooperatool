var config = {
	host: 'http://40.82.136.205:3000'
}
var zuulserver = "http://20.39.185.121"+":5555"
var webserver = zuulserver+"/webserver"
var chattingServer = zuulserver+"/chatserver"