var canvas, context;

window.onload = function () {
  canvas = document.getElementById("cnvs");
  range = document.getElementById("jsRange");
  Erange = document.getElementById("jsERange");
  context = canvas.getContext("2d");
  ccolor = document.getElementById("base");
  initial = document.getElementById("initialization");

  penRadio = document.getElementById("penRadio");
  eraserRadio = document.getElementById("eraserRadio");

  context.lineWidth = 5; //초기 펜 굵기 5로 설정
  context.strokeStyle = ccolor.value;

  // 마우스 리스너 등록. e는 MouseEvent 객체

  canvas.addEventListener(
    "mousemove",
    function (e) {
      move(e);
    },
    false
  );

  canvas.addEventListener(
    "mousedown",
    function (e) {
      down(e);
    },
    false
  );

  canvas.addEventListener(
    "mouseup",
    function (e) {
      up(e);
    },
    false
  );

  canvas.addEventListener(
    "mouseout",
    function (e) {
      out(e);
    },
    false
  );

  range.addEventListener(
    "input",
    function (e) {
      penRadio.checked = true;
      rangechange(e);
    },
    false
  );

  Erange.addEventListener(
    "input",
    function (e) {
      eraserRadio.checked = true;
      Erangechange(e);
    },
    false
  );

  ccolor.addEventListener(
    "input",
    function (e) {
      colorchange(e);
    },
    false
  );

  initial.addEventListener(
    "click",
    function (e) {
      initialize(e);
    },
    false
  );

  penRadio.addEventListener("click", function (e) {
    brushWidth = range.value;
    context.lineWidth = brushWidth;
    context.strokeStyle = ccolor.value;
  });

  eraserRadio.addEventListener("click", function (e) {
    EbrushWidth = Erange.value;
    context.lineWidth = EbrushWidth;
    context.strokeStyle = "#FFFFFF";
  });
};

var startX = 0,
  startY = 0; // 드래깅동안, 처음 마우스가 눌러진 좌표

var drawing = false;

function draw(curX, curY) {
  context.beginPath();

  context.moveTo(startX, startY);

  context.lineTo(curX, curY);

  context.stroke();
}

function down(e) {
  startX = e.offsetX;
  startY = e.offsetY;

  drawing = true;
}

function up(e) {
  drawing = false;
}

function move(e) {
  if (!drawing) return; // 마우스가 눌러지지 않았으면 리턴

  var curX = e.offsetX,
    curY = e.offsetY;

  draw(curX, curY);

  startX = curX;
  startY = curY;
}

function out(e) {
  drawing = false;
}

function rangechange(e) {
  brushWidth = e.target.value;
  context.lineWidth = brushWidth;
  context.strokeStyle = ccolor.value;
}

function Erangechange(e) {
  EbrushWidth = e.target.value;
  context.lineWidth = EbrushWidth;
  context.strokeStyle = "#FFFFFF";
}

function colorchange(e) {
  brushcolor = e.target.value;
  context.strokeStyle = brushcolor;
  context.lineWidth = brushWidth;
}

function initialize(e) {
  context.clearRect(0, 0, canvas.width, canvas.height);
}
